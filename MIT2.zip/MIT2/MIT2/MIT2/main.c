//
//  main.c
//  MIT2
//
//  Created by kirby on 12/19/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#include <stdio.h>
#include "PointerCPP.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    
    struct M; // you can supply only an incomplete declaration
    int call_PointerCPP_foo(struct M*, int i); // declare the wrapper function
    
    //create value and get its address
    int c_variable_a        = 42;
    printf("c_variable_a: %i\n", c_variable_a);
    int * c_variable_a_ptr  = &c_variable_a;
    printf("c_variable_a_ptr: %i\n", c_variable_a_ptr);
    
    int c_variable_b        = 84;
    printf("c_variable_b: %i\n", c_variable_b);
    int * c_variable_b_ptr   = &c_variable_b;
    printf("c_variable_b_ptr: %i\n", c_variable_b_ptr);
    
    
    //c_variable_a_ptr -= 4;
    //printf("c_variable_a_ptr: %i\n", c_variable_a_ptr);
    
    
    //printf("*c_variable_a_ptr: %i\n", *c_variable_a_ptr);
    
    printf("Now let's see if the c++ stuff works:\n");
    
    //i think you should be able to increment c_variable_a_ptr and get the value of c_variable_b
    struct P* p = NULL;
    int c_variable_a_incremented = call_PointerCPP_increment(p, c_variable_a_ptr);
    printf("c_variable_a_incremented: %i\n", c_variable_a_incremented);
    
    struct M* m = NULL;
    int result = call_PointerCPP_foo(m, 42);
    //printf("result: %i\n", result);
    
    //printf("Hello, World!\n");
    return 0;
}
