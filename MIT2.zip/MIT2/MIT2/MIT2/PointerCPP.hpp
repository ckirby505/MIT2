//
//  PointerCPP.hpp
//  MIT2
//
//  Created by kirby on 12/20/18.
//  Copyright © 2018 Chris Kirby. All rights reserved.
//

#ifndef PointerCPP_hpp
#define PointerCPP_hpp

#include <stdio.h>

#endif /* PointerCPP_hpp */

#ifdef __cplusplus

class PointerCPP{
    
public:
    
    int foo(int i){
        return i*2;
    }
    
    int getAddress(){
        return 1;
    }
    
    int  increment(int * ptr){
        //move to the next pointer
        
        //printf("1 ptr: %i\n", ptr);
        //printf("1 *ptr: %i\n", *ptr);
        
        ptr -= 4;//2 bytes for int + 2 bytes for gap maybe
        
        
        //printf("2 ptr: %i\n", ptr);
        //printf("2 *ptr: %i\n", *ptr);
        return *ptr;//value stored at the address the pointer references
    }
};

extern "C" int call_PointerCPP_foo(PointerCPP* pointer_cpp, int i) { return pointer_cpp->foo(i); }
extern "C" int call_PointerCPP_increment(PointerCPP* pointer_cpp, int * ptr) { return pointer_cpp->increment(ptr); }
#endif
int print(int i, double d);

